import React, { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/contexts/AuthContext'
import { 
  Hash, 
  Users, 
  Phone, 
  Video, 
  Settings, 
  Send, 
  Paperclip, 
  Smile,
  MoreHorizontal,
  Reply,
  Edit,
  Trash
} from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface Message {
  id: string
  content: string
  senderId: string
  senderName: string
  senderAvatar?: string
  createdAt: Date
  type: 'TEXT' | 'IMAGE' | 'FILE'
  edited?: boolean
}

interface ChatWindowProps {
  channelId: string
}

export default function ChatWindow({ channelId }: ChatWindowProps) {
  const { user, token } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [typing, setTyping] = useState<string[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Mock channel data
  const channelData = {
    id: channelId,
    name: channelId === '1' ? 'general' : channelId === '2' ? 'development' : 'design',
    type: 'PUBLIC',
    memberCount: 12
  }

  // Mock messages data
  useEffect(() => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setMessages([
        {
          id: '1',
          content: 'Hey everyone! Welcome to the team chat.',
          senderId: '1',
          senderName: 'Alice Johnson',
          createdAt: new Date(Date.now() - 3600000), // 1 hour ago
          type: 'TEXT'
        },
        {
          id: '2',
          content: 'Thanks Alice! Excited to be working with everyone.',
          senderId: '2',
          senderName: 'Bob Smith',
          createdAt: new Date(Date.now() - 3000000), // 50 minutes ago
          type: 'TEXT'
        },
        {
          id: '3',
          content: 'Just pushed the latest updates to the repository. Please review when you get a chance.',
          senderId: '3',
          senderName: 'Charlie Brown',
          createdAt: new Date(Date.now() - 1800000), // 30 minutes ago
          type: 'TEXT'
        },
        {
          id: '4',
          content: 'Looking good! I\'ll test it out this afternoon.',
          senderId: '1',
          senderName: 'Alice Johnson',
          createdAt: new Date(Date.now() - 900000), // 15 minutes ago
          type: 'TEXT'
        }
      ])
      setLoading(false)
    }, 500)
  }, [channelId])

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      content: newMessage,
      senderId: user?.id || '',
      senderName: user?.name || user?.username || 'You',
      senderAvatar: user?.avatar,
      createdAt: new Date(),
      type: 'TEXT'
    }

    setMessages(prev => [...prev, message])
    setNewMessage('')

    // TODO: Send message via WebSocket/API
  }

  const formatMessageTime = (date: Date) => {
    return formatDistanceToNow(date, { addSuffix: true })
  }

  const isConsecutiveMessage = (currentMsg: Message, prevMsg: Message | undefined) => {
    if (!prevMsg) return false
    return (
      currentMsg.senderId === prevMsg.senderId &&
      new Date(currentMsg.createdAt).getTime() - new Date(prevMsg.createdAt).getTime() < 300000 // 5 minutes
    )
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading messages...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Hash className="h-5 w-5 text-muted-foreground" />
            <div>
              <h2 className="text-lg font-semibold text-foreground">{channelData.name}</h2>
              <p className="text-sm text-muted-foreground">{channelData.memberCount} members</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Video className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Users className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message, index) => {
            const prevMessage = index > 0 ? messages[index - 1] : undefined
            const isConsecutive = isConsecutiveMessage(message, prevMessage)
            const isOwnMessage = message.senderId === user?.id

            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`group ${isConsecutive ? 'mt-1' : 'mt-4'}`}
              >
                <div className="flex items-start space-x-3 hover:bg-muted/30 rounded-lg p-2 -m-2 transition-colors">
                  {!isConsecutive && (
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={message.senderAvatar} />
                      <AvatarFallback className="text-xs">
                        {message.senderName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  {isConsecutive && <div className="w-8" />}
                  
                  <div className="flex-1 min-w-0">
                    {!isConsecutive && (
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-sm font-semibold text-foreground">
                          {message.senderName}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatMessageTime(message.createdAt)}
                        </span>
                        {message.edited && (
                          <Badge variant="secondary" className="text-xs">edited</Badge>
                        )}
                      </div>
                    )}
                    <div className="text-sm text-foreground leading-relaxed">
                      {message.content}
                    </div>
                  </div>

                  {/* Message actions */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center space-x-1">
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                      <Reply className="h-3 w-3" />
                    </Button>
                    {isOwnMessage && (
                      <>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <Trash className="h-3 w-3" />
                        </Button>
                      </>
                    )}
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                      <MoreHorizontal className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            )
          })}
          
          {/* Typing indicator */}
          {typing.length > 0 && (
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
              <span>{typing.join(', ')} {typing.length === 1 ? 'is' : 'are'} typing...</span>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Message Input */}
      <div className="p-4 border-t border-border bg-card">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <Button type="button" variant="ghost" size="sm">
            <Paperclip className="h-4 w-4" />
          </Button>
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder={`Message #${channelData.name}`}
              className="pr-10"
            />
            <Button 
              type="button" 
              variant="ghost" 
              size="sm" 
              className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
            >
              <Smile className="h-4 w-4" />
            </Button>
          </div>
          <Button type="submit" disabled={!newMessage.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}