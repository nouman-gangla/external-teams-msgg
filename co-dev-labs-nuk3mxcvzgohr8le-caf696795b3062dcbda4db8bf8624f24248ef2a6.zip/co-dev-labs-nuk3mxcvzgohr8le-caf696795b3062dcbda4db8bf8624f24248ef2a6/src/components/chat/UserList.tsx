import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/contexts/AuthContext'

interface User {
  id: string
  username: string
  name?: string
  avatar?: string
  status: 'ONLINE' | 'AWAY' | 'BUSY' | 'OFFLINE'
  unreadCount?: number
}

export default function UserList() {
  const { token } = useAuth()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  // Mock data for now - will be replaced with real API calls
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setUsers([
        { id: '1', username: 'alice', name: 'Alice Johnson', status: 'ONLINE', unreadCount: 2 },
        { id: '2', username: 'bob', name: 'Bob Smith', status: 'AWAY', unreadCount: 0 },
        { id: '3', username: 'charlie', name: 'Charlie Brown', status: 'BUSY', unreadCount: 1 },
        { id: '4', username: 'diana', name: 'Diana Prince', status: 'OFFLINE', unreadCount: 0 },
      ])
      setLoading(false)
    }, 1000)
  }, [])

  const getStatusColor = (status: User['status']) => {
    switch (status) {
      case 'ONLINE':
        return 'bg-green-500'
      case 'AWAY':
        return 'bg-yellow-500'
      case 'BUSY':
        return 'bg-red-500'
      case 'OFFLINE':
        return 'bg-gray-400'
      default:
        return 'bg-gray-400'
    }
  }

  if (loading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-8 bg-muted/50 rounded animate-pulse" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-1">
      {users.map((user) => (
        <Button
          key={user.id}
          variant="ghost"
          className="w-full justify-start h-10 px-2"
        >
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <div className="relative">
              <Avatar className="h-6 w-6">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="text-xs">
                  {user.name?.charAt(0) || user.username.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div 
                className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background ${getStatusColor(user.status)}`}
              />
            </div>
            <span className="text-sm truncate">{user.name || user.username}</span>
          </div>
          {user.unreadCount && user.unreadCount > 0 && (
            <Badge variant="destructive" className="h-5 w-5 p-0 text-xs flex items-center justify-center">
              {user.unreadCount > 99 ? '99+' : user.unreadCount}
            </Badge>
          )}
        </Button>
      ))}
    </div>
  )
}