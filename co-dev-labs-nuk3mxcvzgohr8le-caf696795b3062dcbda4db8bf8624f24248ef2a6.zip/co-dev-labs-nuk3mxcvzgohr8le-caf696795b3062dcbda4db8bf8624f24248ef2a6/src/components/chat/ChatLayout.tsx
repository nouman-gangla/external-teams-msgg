import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { useAuth } from '@/contexts/AuthContext'
import { 
  MessageCircle, 
  Hash, 
  Users, 
  Settings, 
  LogOut, 
  Plus,
  Search,
  Bell,
  Phone,
  Video,
  MoreHorizontal
} from 'lucide-react'
import ChatWindow from './ChatWindow'
import ChannelList from './ChannelList'
import UserList from './UserList'

export default function ChatLayout() {
  const { user, logout } = useAuth()
  const [activeChannel, setActiveChannel] = useState<string | null>(null)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const handleLogout = async () => {
    await logout()
  }

  return (
    <div className="h-screen flex bg-background">
      {/* Sidebar */}
      <motion.div
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        transition={{ duration: 0.3 }}
        className={`${
          sidebarCollapsed ? 'w-16' : 'w-80'
        } bg-card border-r border-border flex flex-col transition-all duration-300`}
      >
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            {!sidebarCollapsed && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary rounded-lg">
                  <MessageCircle className="h-6 w-6 text-primary-foreground" />
                </div>
                <h1 className="text-xl font-bold text-foreground">ChatFlow</h1>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* User Profile */}
        {!sidebarCollapsed && (
          <div className="p-4 border-b border-border">
            <div className="flex items-center space-x-3">
              <Avatar>
                <AvatarImage src={user?.avatar} />
                <AvatarFallback>
                  {user?.name?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {user?.name || user?.username}
                </p>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <p className="text-xs text-muted-foreground">Online</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="p-2 space-y-2">
              {!sidebarCollapsed && (
                <>
                  {/* Quick Actions */}
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start" size="sm">
                      <Search className="h-4 w-4 mr-2" />
                      Search
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" size="sm">
                      <Bell className="h-4 w-4 mr-2" />
                      Notifications
                    </Button>
                  </div>
                  
                  <Separator />
                  
                  {/* Channels Section */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-2">
                      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Channels
                      </h3>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <ChannelList 
                      activeChannel={activeChannel}
                      onChannelSelect={setActiveChannel}
                    />
                  </div>
                  
                  <Separator />
                  
                  {/* Direct Messages */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-2">
                      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Direct Messages
                      </h3>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <UserList />
                  </div>
                </>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Settings */}
        {!sidebarCollapsed && (
          <div className="p-4 border-t border-border">
            <Button variant="ghost" className="w-full justify-start" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        )}
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {activeChannel ? (
          <ChatWindow channelId={activeChannel} />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex-1 flex items-center justify-center bg-muted/20"
          >
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <MessageCircle className="h-12 w-12 text-primary" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold text-foreground">Welcome to ChatFlow</h2>
                <p className="text-muted-foreground max-w-md">
                  Select a channel or start a direct message to begin chatting with your team.
                </p>
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Channel
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}