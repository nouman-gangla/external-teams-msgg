import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Hash, Lock, Volume2 } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface Channel {
  id: string
  name: string
  type: 'PUBLIC' | 'PRIVATE'
  unreadCount?: number
}

interface ChannelListProps {
  activeChannel: string | null
  onChannelSelect: (channelId: string) => void
}

export default function ChannelList({ activeChannel, onChannelSelect }: ChannelListProps) {
  const { token } = useAuth()
  const [channels, setChannels] = useState<Channel[]>([])
  const [loading, setLoading] = useState(true)

  // Mock data for now - will be replaced with real API calls
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setChannels([
        { id: '1', name: 'general', type: 'PUBLIC', unreadCount: 3 },
        { id: '2', name: 'development', type: 'PUBLIC', unreadCount: 0 },
        { id: '3', name: 'design', type: 'PUBLIC', unreadCount: 1 },
        { id: '4', name: 'private-team', type: 'PRIVATE', unreadCount: 0 },
      ])
      setLoading(false)
    }, 1000)
  }, [])

  if (loading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-8 bg-muted/50 rounded animate-pulse" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-1">
      {channels.map((channel) => (
        <Button
          key={channel.id}
          variant={activeChannel === channel.id ? "secondary" : "ghost"}
          className="w-full justify-start h-8 px-2"
          onClick={() => onChannelSelect(channel.id)}
        >
          <div className="flex items-center space-x-2 flex-1 min-w-0">
            {channel.type === 'PRIVATE' ? (
              <Lock className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            ) : (
              <Hash className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            )}
            <span className="text-sm truncate">{channel.name}</span>
          </div>
          {channel.unreadCount && channel.unreadCount > 0 && (
            <Badge variant="destructive" className="h-5 w-5 p-0 text-xs flex items-center justify-center">
              {channel.unreadCount > 99 ? '99+' : channel.unreadCount}
            </Badge>
          )}
        </Button>
      ))}
    </div>
  )
}